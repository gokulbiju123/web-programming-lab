from django.db import models

# Create your models here.
class registration(models.Model):
    cid=models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')
    f_name=models.CharField(max_length=250)
    l_name=models.CharField(max_length=250)
    username=models.CharField(max_length=350)
    password=models.CharField(max_length=350)
    gender=models.CharField(max_length=350)
    email=models.CharField(max_length=350)
    ph_number=models.IntegerField()
    house_no=models.CharField(max_length=250)
    per_address=models.TextField()
   
    class login(models.Model):
        username=models.CharField(primary_key=True,verbose_name='Id',max_length=350)
        password=models.CharField(max_length=350)
    
    

    

    