

from newapp import views
from django.urls import path



urlpatterns = [
    path('',views.index,name='index'),
    path('login',views.login,name='login'),
    path('signup',views.signup,name='signup'),
    path('about',views.about,name='about'),
    path('userhome',views.userhome,name='userhome'),
    path('joinchitty',views.joinchitty,name='joinchitty'),
    path('payment',views.payment,name='payment'),
    path('pay',views.pay,name='pay'),
    
]
