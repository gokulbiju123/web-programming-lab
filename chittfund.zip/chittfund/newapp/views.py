from django.shortcuts import render
from . models import registration

# Create your views here.
def index(request):
    return render(request,'index.html')

def login(request):
    return render(request,'login.html')

def signup(request):
    if request.POST:
        f_name=request.POST.get('fname')
        l_name=request.POST.get('lname')
        username=request.POST.get('username')
        password=request.POST.get('password')
        gender=request.POST.get('gender')
        email=request.POST.get('email')
        ph_number=request.POST.get('ph_number')
        house_no=request.POST.get('house_no')
        per_address=request.POST.get('per_address')

        sign=registration( f_name=f_name, l_name=l_name, username=username, password=password,  gender=gender,  email=email, ph_number=ph_number, house_no=house_no,  per_address=per_address)
        sign.save()
    return render(request,'signup.html')

def about(request):
    return render(request,'about.html')

def userhome(request):
    return render(request,'userhome.html')

def joinchitty(request):
    return render(request,'joinchitty.html')

def payment(request):
    return render(request,'payment.html')

def pay(request):
    return render(request,'pay.html')


